package com.example.dataforge.api.dto;

import java.util.List;
import java.util.Map;

public record AgentChatResponse(
        Long runId,
        String answer,
        String sql,
        List<String> columns,
        List<Map<String, Object>> rows,
        List<String> insights,
        String reportMarkdown,
        List<AgentStepDto> steps
) {}
