package com.example.dataforge.domain.dataset;

import java.util.List;
import java.util.Map;

public record DatasetProfile(
        long rowCount,
        List<ColumnProfile> columns,
        List<Map<String, Object>> sampleRows
) {}
