package com.example.dataforge.api;

import com.example.dataforge.api.dto.DatasetProfileResponse;
import com.example.dataforge.api.dto.DatasetSummaryResponse;
import com.example.dataforge.application.DatasetService;
import com.example.dataforge.common.ApiResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/datasets")
public class DatasetController {
    private final DatasetService datasetService;

    public DatasetController(DatasetService datasetService) {
        this.datasetService = datasetService;
    }

    @PostMapping
    public ApiResponse<DatasetSummaryResponse> upload(@RequestParam("file") MultipartFile file) {
        return ApiResponse.ok(datasetService.uploadCsv(file));
    }

    @GetMapping
    public ApiResponse<List<DatasetSummaryResponse>> list() {
        return ApiResponse.ok(datasetService.list());
    }

    @GetMapping("/{id}/profile")
    public ApiResponse<DatasetProfileResponse> profile(@PathVariable Long id) {
        return ApiResponse.ok(datasetService.profile(id));
    }
}
