package com.example.dataforge.application;

import com.example.dataforge.api.dto.AgentChatRequest;
import com.example.dataforge.api.dto.AgentChatResponse;
import com.example.dataforge.api.dto.AgentStepDto;
import com.example.dataforge.application.agents.DatasetContextAgent;
import com.example.dataforge.application.agents.InsightAgent;
import com.example.dataforge.application.agents.IntentAgent;
import com.example.dataforge.application.agents.QueryExecuteAgent;
import com.example.dataforge.application.agents.ReportAgent;
import com.example.dataforge.application.agents.SqlPlannerAgent;
import com.example.dataforge.common.BusinessException;
import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.agent.AgentStep;
import com.example.dataforge.domain.dataset.DatasetProfile;
import com.example.dataforge.infrastructure.persistence.AgentRunEntity;
import com.example.dataforge.infrastructure.persistence.AgentRunRepository;
import com.example.dataforge.infrastructure.persistence.DatasetEntity;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AgentOrchestrator {
    private final DatasetService datasetService;
    private final AgentRunRepository agentRunRepository;
    private final ObjectMapper objectMapper;
    private final DatasetContextAgent datasetContextAgent;
    private final IntentAgent intentAgent;
    private final SqlPlannerAgent sqlPlannerAgent;
    private final QueryExecuteAgent queryExecuteAgent;
    private final InsightAgent insightAgent;
    private final ReportAgent reportAgent;

    public AgentOrchestrator(DatasetService datasetService,
                             AgentRunRepository agentRunRepository,
                             ObjectMapper objectMapper,
                             DatasetContextAgent datasetContextAgent,
                             IntentAgent intentAgent,
                             SqlPlannerAgent sqlPlannerAgent,
                             QueryExecuteAgent queryExecuteAgent,
                             InsightAgent insightAgent,
                             ReportAgent reportAgent) {
        this.datasetService = datasetService;
        this.agentRunRepository = agentRunRepository;
        this.objectMapper = objectMapper;
        this.datasetContextAgent = datasetContextAgent;
        this.intentAgent = intentAgent;
        this.sqlPlannerAgent = sqlPlannerAgent;
        this.queryExecuteAgent = queryExecuteAgent;
        this.insightAgent = insightAgent;
        this.reportAgent = reportAgent;
    }

    @Transactional
    public AgentChatResponse answer(AgentChatRequest request) {
        DatasetEntity dataset = datasetService.getEntity(request.datasetId());
        DatasetProfile profile = datasetService.toProfile(dataset);
        AgentContext context = new AgentContext(dataset, profile, request.question());
        AgentRunEntity run = agentRunRepository.save(new AgentRunEntity(dataset.getId(), request.question()));
        try {
            datasetContextAgent.run(context);
            intentAgent.run(context);
            sqlPlannerAgent.run(context);
            queryExecuteAgent.run(context);
            insightAgent.run(context);
            reportAgent.run(context);

            AgentChatResponse response = toResponse(run.getId(), context);
            run.success(context.getPlannedSql(), objectMapper.writeValueAsString(response), objectMapper.writeValueAsString(context.getSteps()));
            agentRunRepository.save(run);
            return response;
        } catch (Exception e) {
            try {
                run.fail(e.getMessage(), objectMapper.writeValueAsString(context.getSteps()));
                agentRunRepository.save(run);
            } catch (Exception ignored) {}
            if (e instanceof BusinessException be) throw be;
            throw new BusinessException("Agent 协作失败：" + e.getMessage());
        }
    }

    private AgentChatResponse toResponse(Long runId, AgentContext context) {
        List<AgentStepDto> steps = context.getSteps().stream().map(this::toStep).toList();
        String answer = context.getInsights().isEmpty()
                ? "分析完成，但没有生成明显洞察。"
                : String.join("", context.getInsights());
        return new AgentChatResponse(
                runId,
                answer,
                context.getPlannedSql(),
                context.getQueryResult().columns(),
                context.getQueryResult().rows(),
                context.getInsights(),
                context.getReportMarkdown(),
                steps
        );
    }

    private AgentStepDto toStep(AgentStep step) {
        return new AgentStepDto(step.agentName(), step.input(), step.output(), step.status(), step.latencyMs(), step.estimatedTokens());
    }
}
