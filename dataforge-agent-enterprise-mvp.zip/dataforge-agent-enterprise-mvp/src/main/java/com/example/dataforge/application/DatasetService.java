package com.example.dataforge.application;

import com.example.dataforge.api.dto.DatasetProfileResponse;
import com.example.dataforge.api.dto.DatasetSummaryResponse;
import com.example.dataforge.common.BusinessException;
import com.example.dataforge.domain.dataset.ColumnProfile;
import com.example.dataforge.domain.dataset.DatasetProfile;
import com.example.dataforge.infrastructure.csv.CsvProfiler;
import com.example.dataforge.infrastructure.persistence.DatasetEntity;
import com.example.dataforge.infrastructure.persistence.DatasetRepository;
import com.example.dataforge.infrastructure.storage.LocalFileStorageService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@Service
public class DatasetService {
    private final LocalFileStorageService storageService;
    private final CsvProfiler csvProfiler;
    private final DatasetRepository datasetRepository;
    private final ObjectMapper objectMapper;

    public DatasetService(LocalFileStorageService storageService,
                          CsvProfiler csvProfiler,
                          DatasetRepository datasetRepository,
                          ObjectMapper objectMapper) {
        this.storageService = storageService;
        this.csvProfiler = csvProfiler;
        this.datasetRepository = datasetRepository;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public DatasetSummaryResponse uploadCsv(MultipartFile file) {
        LocalFileStorageService.StoredFile stored = storageService.storeCsv(file);
        DatasetProfile profile = csvProfiler.profile(stored.path());
        try {
            DatasetEntity entity = new DatasetEntity(
                    stored.originalFilename(),
                    stored.path().toString(),
                    profile.rowCount(),
                    profile.columns().size(),
                    objectMapper.writeValueAsString(profile.columns()),
                    objectMapper.writeValueAsString(profile.sampleRows()),
                    Instant.now()
            );
            DatasetEntity saved = datasetRepository.save(entity);
            return toSummary(saved);
        } catch (Exception e) {
            throw new BusinessException("数据集元数据保存失败：" + e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public List<DatasetSummaryResponse> list() {
        return datasetRepository.findAll().stream().map(this::toSummary).toList();
    }

    @Transactional(readOnly = true)
    public DatasetProfileResponse profile(Long id) {
        DatasetEntity entity = getEntity(id);
        DatasetProfile p = toProfile(entity);
        return new DatasetProfileResponse(entity.getId(), entity.getOriginalFilename(), entity.getRowCount(),
                p.columns(), p.sampleRows(), entity.getCreatedAt());
    }

    @Transactional(readOnly = true)
    public DatasetEntity getEntity(Long id) {
        return datasetRepository.findById(id).orElseThrow(() -> new BusinessException("数据集不存在：" + id));
    }

    public DatasetProfile toProfile(DatasetEntity entity) {
        try {
            List<ColumnProfile> columns = objectMapper.readValue(entity.getColumnsJson(), new TypeReference<>() {});
            List<Map<String, Object>> sampleRows = objectMapper.readValue(entity.getSampleRowsJson(), new TypeReference<>() {});
            return new DatasetProfile(entity.getRowCount(), columns, sampleRows);
        } catch (Exception e) {
            throw new BusinessException("数据集画像反序列化失败：" + e.getMessage());
        }
    }

    private DatasetSummaryResponse toSummary(DatasetEntity entity) {
        return new DatasetSummaryResponse(entity.getId(), entity.getOriginalFilename(), entity.getRowCount(),
                entity.getColumnCount(), entity.getCreatedAt());
    }
}
