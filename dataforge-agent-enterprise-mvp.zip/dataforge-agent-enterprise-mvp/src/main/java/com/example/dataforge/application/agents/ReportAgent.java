package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.stream.Collectors;

@Component
public class ReportAgent extends AbstractAgent {
    @Override
    protected String name() { return "ReportAgent"; }

    @Override
    protected String input(AgentContext context) {
        return "question=" + context.getQuestion() + ", insights=" + context.getInsights().size();
    }

    @Override
    protected String doRun(AgentContext context) {
        String sample = context.getQueryResult() == null ? "无" : context.getQueryResult().rows().stream()
                .limit(5)
                .map(Map::toString)
                .collect(Collectors.joining("\n"));
        String steps = context.getSteps().stream()
                .map(s -> "- " + s.agentName() + "：" + s.status() + "，耗时 " + s.latencyMs() + "ms，估算 Token " + s.estimatedTokens())
                .collect(Collectors.joining("\n"));
        String insights = context.getInsights().stream().map(i -> "- " + i).collect(Collectors.joining("\n"));
        String report = "# DataForge 数据分析报告\n\n" +
                "## 1. 用户问题\n" + context.getQuestion() + "\n\n" +
                "## 2. 数据集概况\n" +
                "- 数据集：" + context.getDataset().getOriginalFilename() + "\n" +
                "- 行数：" + context.getDatasetProfile().rowCount() + "\n" +
                "- 字段数：" + context.getDatasetProfile().columns().size() + "\n\n" +
                "## 3. 执行 SQL\n```sql\n" + context.getPlannedSql() + "\n```\n\n" +
                "## 4. 结果预览\n```text\n" + sample + "\n```\n\n" +
                "## 5. 关键洞察\n" + insights + "\n\n" +
                "## 6. Agent 协作轨迹\n" + steps + "\n";
        context.setReportMarkdown(report);
        return "已生成 Markdown 报告，长度=" + report.length();
    }
}
