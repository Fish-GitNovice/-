package com.example.dataforge.infrastructure.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "agent_runs")
public class AgentRunEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private Long datasetId;

    @Column(nullable = false, length = 1000)
    private String question;

    @Column(nullable = false, length = 32)
    private String status;

    @Column(columnDefinition = "CLOB")
    private String plannedSql;

    @Column(columnDefinition = "CLOB")
    private String resultJson;

    @Column(columnDefinition = "CLOB")
    private String traceJson;

    @Column(columnDefinition = "CLOB")
    private String errorMessage;

    @Column(nullable = false)
    private Instant createdAt;

    @Column(nullable = false)
    private Instant updatedAt;

    protected AgentRunEntity() {}

    public AgentRunEntity(Long datasetId, String question) {
        this.datasetId = datasetId;
        this.question = question;
        this.status = "RUNNING";
        this.createdAt = Instant.now();
        this.updatedAt = this.createdAt;
    }

    public Long getId() { return id; }
    public Long getDatasetId() { return datasetId; }
    public String getQuestion() { return question; }
    public String getStatus() { return status; }

    public void success(String plannedSql, String resultJson, String traceJson) {
        this.status = "SUCCESS";
        this.plannedSql = plannedSql;
        this.resultJson = resultJson;
        this.traceJson = traceJson;
        this.updatedAt = Instant.now();
    }

    public void fail(String errorMessage, String traceJson) {
        this.status = "FAILED";
        this.errorMessage = errorMessage;
        this.traceJson = traceJson;
        this.updatedAt = Instant.now();
    }
}
