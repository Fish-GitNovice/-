package com.example.dataforge.domain.dataset;

import java.util.List;

public record ColumnProfile(
        String name,
        String type,
        long totalCount,
        long missingCount,
        long distinctCount,
        Double min,
        Double max,
        Double avg,
        List<String> examples
) {}
