package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.agent.AgentStep;

public abstract class AbstractAgent implements Agent {
    @Override
    public final AgentStep run(AgentContext context) {
        long start = System.currentTimeMillis();
        String input = input(context);
        try {
            String output = doRun(context);
            AgentStep step = new AgentStep(name(), input, output, "SUCCESS", System.currentTimeMillis() - start,
                    estimateTokens(input + output));
            context.addStep(step);
            return step;
        } catch (RuntimeException e) {
            AgentStep step = new AgentStep(name(), input, e.getMessage(), "FAILED", System.currentTimeMillis() - start,
                    estimateTokens(input + e.getMessage()));
            context.addStep(step);
            throw e;
        }
    }

    protected abstract String name();
    protected abstract String input(AgentContext context);
    protected abstract String doRun(AgentContext context);

    private int estimateTokens(String text) {
        if (text == null || text.isBlank()) return 0;
        return Math.max(1, text.length() / 3);
    }
}
