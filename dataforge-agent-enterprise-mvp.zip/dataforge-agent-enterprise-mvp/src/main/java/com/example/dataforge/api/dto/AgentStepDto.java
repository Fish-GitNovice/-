package com.example.dataforge.api.dto;

public record AgentStepDto(
        String agentName,
        String input,
        String output,
        String status,
        long latencyMs,
        int estimatedTokens
) {}
