package com.example.dataforge.infrastructure.storage;

import com.example.dataforge.common.BusinessException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.UUID;

@Service
public class LocalFileStorageService {
    private final Path root;

    public LocalFileStorageService(@Value("${app.storage.root}") String root) {
        this.root = Path.of(root).toAbsolutePath().normalize();
    }

    public StoredFile storeCsv(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new BusinessException("上传文件不能为空");
        }
        String original = StringUtils.cleanPath(file.getOriginalFilename() == null ? "dataset.csv" : file.getOriginalFilename());
        if (!original.toLowerCase().endsWith(".csv")) {
            throw new BusinessException("当前 MVP 只支持 CSV 文件");
        }
        try {
            Path dir = root.resolve(LocalDate.now().toString());
            Files.createDirectories(dir);
            String storedName = UUID.randomUUID() + "-" + original.replaceAll("[^a-zA-Z0-9._\\-\\u4e00-\\u9fa5]", "_");
            Path target = dir.resolve(storedName).normalize();
            if (!target.startsWith(root)) {
                throw new BusinessException("非法文件路径");
            }
            file.transferTo(target);
            return new StoredFile(original, target);
        } catch (IOException e) {
            throw new BusinessException("文件保存失败：" + e.getMessage());
        }
    }

    public record StoredFile(String originalFilename, Path path) {}
}
