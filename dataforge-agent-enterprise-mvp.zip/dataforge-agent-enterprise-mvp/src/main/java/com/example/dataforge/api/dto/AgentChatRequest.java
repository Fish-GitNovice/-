package com.example.dataforge.api.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public record AgentChatRequest(
        @NotNull Long datasetId,
        @NotBlank @Size(max = 1000) String question
) {}
