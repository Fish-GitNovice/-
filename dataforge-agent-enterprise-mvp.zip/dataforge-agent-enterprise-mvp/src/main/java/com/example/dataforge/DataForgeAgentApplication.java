package com.example.dataforge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@SpringBootApplication
public class DataForgeAgentApplication {
    public static void main(String[] args) {
        SpringApplication.run(DataForgeAgentApplication.class, args);
    }
}
