package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.agent.QueryResult;
import com.example.dataforge.infrastructure.duckdb.DuckDbQueryEngine;
import com.example.dataforge.infrastructure.duckdb.SqlSafetyInspector;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.nio.file.Path;

@Component
public class QueryExecuteAgent extends AbstractAgent {
    private final SqlSafetyInspector safetyInspector;
    private final DuckDbQueryEngine queryEngine;
    private final int maxPreviewRows;

    public QueryExecuteAgent(SqlSafetyInspector safetyInspector,
                             DuckDbQueryEngine queryEngine,
                             @Value("${app.agent.max-preview-rows:50}") int maxPreviewRows) {
        this.safetyInspector = safetyInspector;
        this.queryEngine = queryEngine;
        this.maxPreviewRows = maxPreviewRows;
    }

    @Override
    protected String name() { return "QueryExecuteAgent"; }

    @Override
    protected String input(AgentContext context) { return context.getPlannedSql(); }

    @Override
    protected String doRun(AgentContext context) {
        String safeSql = safetyInspector.assertSafeSelect(context.getPlannedSql());
        QueryResult result = queryEngine.execute(Path.of(context.getDataset().getStoredPath()), safeSql, maxPreviewRows);
        context.setQueryResult(result);
        return "查询成功，返回列=" + result.columns() + "，预览行数=" + result.rowCount();
    }
}
