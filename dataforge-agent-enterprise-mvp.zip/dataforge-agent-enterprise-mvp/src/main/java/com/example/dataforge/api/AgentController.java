package com.example.dataforge.api;

import com.example.dataforge.api.dto.AgentChatRequest;
import com.example.dataforge.api.dto.AgentChatResponse;
import com.example.dataforge.application.AgentOrchestrator;
import com.example.dataforge.common.ApiResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/agent")
public class AgentController {
    private final AgentOrchestrator agentOrchestrator;

    public AgentController(AgentOrchestrator agentOrchestrator) {
        this.agentOrchestrator = agentOrchestrator;
    }

    @PostMapping("/chat")
    public ApiResponse<AgentChatResponse> chat(@RequestBody @Valid AgentChatRequest request) {
        return ApiResponse.ok(agentOrchestrator.answer(request));
    }
}
