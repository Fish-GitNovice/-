package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.agent.AgentStep;

public interface Agent {
    AgentStep run(AgentContext context);
}
