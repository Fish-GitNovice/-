package com.example.dataforge.infrastructure.duckdb;

import com.example.dataforge.common.BusinessException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Component
public class SqlSafetyInspector {
    private static final Pattern DATASET_TABLE = Pattern.compile("(?i)\\bfrom\\s+dataset\\b|\\bjoin\\s+dataset\\b");
    private static final List<String> BLOCKED = List.of(
            "insert", "update", "delete", "drop", "alter", "create", "truncate", "merge",
            "copy", "attach", "detach", "install", "load", "pragma", "call", "export", "import",
            "read_parquet", "read_json", "read_csv", "read_csv_auto", "httpfs", "sqlite_scan"
    );

    public String assertSafeSelect(String sql) {
        if (sql == null || sql.isBlank()) {
            throw new BusinessException("SQL 不能为空");
        }
        String trimmed = sql.trim();
        if (trimmed.endsWith(";")) {
            trimmed = trimmed.substring(0, trimmed.length() - 1).trim();
        }
        String lower = trimmed.toLowerCase(Locale.ROOT);
        if (!lower.startsWith("select ")) {
            throw new BusinessException("SQL 安全护栏：只允许 SELECT 查询");
        }
        if (trimmed.contains(";") || lower.contains("--") || lower.contains("/*") || lower.contains("*/")) {
            throw new BusinessException("SQL 安全护栏：不允许多语句或注释注入");
        }
        for (String word : BLOCKED) {
            if (Pattern.compile("(?i)\\b" + Pattern.quote(word) + "\\b").matcher(lower).find()) {
                throw new BusinessException("SQL 安全护栏：禁止关键字 " + word);
            }
        }
        if (!DATASET_TABLE.matcher(trimmed).find()) {
            throw new BusinessException("SQL 安全护栏：只能查询虚拟表 dataset");
        }
        if (trimmed.length() > 5000) {
            throw new BusinessException("SQL 过长，已拒绝执行");
        }
        return trimmed;
    }
}
