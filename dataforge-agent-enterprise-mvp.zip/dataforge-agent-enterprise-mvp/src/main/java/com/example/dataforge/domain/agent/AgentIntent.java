package com.example.dataforge.domain.agent;

public enum AgentIntent {
    KPI_QUERY,
    RANKING,
    ANOMALY_DETECTION,
    TREND_ANALYSIS,
    REPORT_GENERATION,
    SQL_GENERATION
}
