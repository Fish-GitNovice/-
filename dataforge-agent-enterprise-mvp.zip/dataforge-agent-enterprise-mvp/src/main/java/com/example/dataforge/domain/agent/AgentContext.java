package com.example.dataforge.domain.agent;

import com.example.dataforge.domain.dataset.DatasetProfile;
import com.example.dataforge.infrastructure.persistence.DatasetEntity;

import java.util.ArrayList;
import java.util.List;

public class AgentContext {
    private final DatasetEntity dataset;
    private final DatasetProfile datasetProfile;
    private final String question;
    private AgentIntent intent;
    private String plannedSql;
    private QueryResult queryResult;
    private final List<String> insights = new ArrayList<>();
    private String reportMarkdown;
    private final List<AgentStep> steps = new ArrayList<>();

    public AgentContext(DatasetEntity dataset, DatasetProfile datasetProfile, String question) {
        this.dataset = dataset;
        this.datasetProfile = datasetProfile;
        this.question = question;
    }

    public DatasetEntity getDataset() { return dataset; }
    public DatasetProfile getDatasetProfile() { return datasetProfile; }
    public String getQuestion() { return question; }
    public AgentIntent getIntent() { return intent; }
    public void setIntent(AgentIntent intent) { this.intent = intent; }
    public String getPlannedSql() { return plannedSql; }
    public void setPlannedSql(String plannedSql) { this.plannedSql = plannedSql; }
    public QueryResult getQueryResult() { return queryResult; }
    public void setQueryResult(QueryResult queryResult) { this.queryResult = queryResult; }
    public List<String> getInsights() { return insights; }
    public String getReportMarkdown() { return reportMarkdown; }
    public void setReportMarkdown(String reportMarkdown) { this.reportMarkdown = reportMarkdown; }
    public List<AgentStep> getSteps() { return steps; }
    public void addStep(AgentStep step) { this.steps.add(step); }
}
