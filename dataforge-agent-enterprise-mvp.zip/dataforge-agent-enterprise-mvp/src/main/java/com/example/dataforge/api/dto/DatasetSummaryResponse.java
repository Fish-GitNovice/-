package com.example.dataforge.api.dto;

import java.time.Instant;

public record DatasetSummaryResponse(
        Long id,
        String name,
        long rowCount,
        int columnCount,
        Instant createdAt
) {}
