package com.example.dataforge.infrastructure.duckdb;

import com.example.dataforge.common.BusinessException;
import com.example.dataforge.domain.agent.QueryResult;
import org.springframework.stereotype.Component;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Component
public class DuckDbQueryEngine {
    public QueryResult execute(Path csvPath, String safeSql, int maxRows) {
        String query = withLimit(safeSql, maxRows);
        try (Connection conn = DriverManager.getConnection("jdbc:duckdb:");
             Statement statement = conn.createStatement()) {
            String escaped = csvPath.toAbsolutePath().normalize().toString().replace("'", "''");
            statement.execute("CREATE TEMP VIEW dataset AS SELECT * FROM read_csv_auto('" + escaped + "', HEADER=true)");
            try (ResultSet rs = statement.executeQuery(query)) {
                ResultSetMetaData md = rs.getMetaData();
                List<String> columns = new ArrayList<>();
                for (int i = 1; i <= md.getColumnCount(); i++) {
                    columns.add(md.getColumnLabel(i));
                }
                List<Map<String, Object>> rows = new ArrayList<>();
                while (rs.next()) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (int i = 1; i <= md.getColumnCount(); i++) {
                        row.put(columns.get(i - 1), rs.getObject(i));
                    }
                    rows.add(row);
                }
                return new QueryResult(columns, rows);
            }
        } catch (Exception e) {
            throw new BusinessException("DuckDB 查询失败：" + e.getMessage());
        }
    }

    private String withLimit(String sql, int maxRows) {
        String lower = sql.toLowerCase(Locale.ROOT);
        if (lower.matches("(?s).*\\blimit\\s+\\d+.*")) {
            return sql;
        }
        return sql + " LIMIT " + Math.max(1, maxRows);
    }
}
