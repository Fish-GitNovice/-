package com.example.dataforge.infrastructure.csv;

import com.example.dataforge.common.BusinessException;
import com.example.dataforge.domain.dataset.ColumnProfile;
import com.example.dataforge.domain.dataset.DatasetProfile;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

@Component
public class CsvProfiler {
    private final int maxProfileRows;

    public CsvProfiler(@Value("${app.agent.max-profile-rows:10000}") int maxProfileRows) {
        this.maxProfileRows = maxProfileRows;
    }

    public DatasetProfile profile(Path path) {
        try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);
             CSVParser parser = CSVFormat.DEFAULT.builder()
                     .setHeader()
                     .setSkipHeaderRecord(true)
                     .setTrim(true)
                     .build()
                     .parse(reader)) {

            List<String> headers = new ArrayList<>(parser.getHeaderMap().keySet());
            if (headers.isEmpty()) {
                throw new BusinessException("CSV 表头不能为空");
            }
            Map<String, Stats> stats = new LinkedHashMap<>();
            headers.forEach(h -> stats.put(h, new Stats()));
            List<Map<String, Object>> sampleRows = new ArrayList<>();
            long totalRows = 0;

            for (CSVRecord record : parser) {
                totalRows++;
                if (sampleRows.size() < 10) {
                    Map<String, Object> row = new LinkedHashMap<>();
                    for (String h : headers) {
                        row.put(h, value(record, h));
                    }
                    sampleRows.add(row);
                }
                if (totalRows <= maxProfileRows) {
                    for (String h : headers) {
                        stats.get(h).accept(value(record, h));
                    }
                }
            }

            List<ColumnProfile> profiles = new ArrayList<>();
            for (String h : headers) {
                profiles.add(stats.get(h).toProfile(h, Math.min(totalRows, maxProfileRows)));
            }
            return new DatasetProfile(totalRows, profiles, sampleRows);
        } catch (IOException e) {
            throw new BusinessException("CSV 解析失败：" + e.getMessage());
        }
    }

    private String value(CSVRecord record, String header) {
        try {
            return record.isSet(header) ? record.get(header) : null;
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    static class Stats {
        long missing;
        long nonMissing;
        long numericCount;
        long dateCount;
        BigDecimal sum = BigDecimal.ZERO;
        Double min;
        Double max;
        final Set<String> distinct = new HashSet<>();
        final List<String> examples = new ArrayList<>();

        void accept(String raw) {
            String v = raw == null ? null : raw.trim();
            if (v == null || v.isEmpty()) {
                missing++;
                return;
            }
            nonMissing++;
            if (distinct.size() < 5000) distinct.add(v);
            if (examples.size() < 5 && !examples.contains(v)) examples.add(v);

            Double d = parseDouble(v);
            if (d != null) {
                numericCount++;
                sum = sum.add(BigDecimal.valueOf(d));
                min = min == null ? d : Math.min(min, d);
                max = max == null ? d : Math.max(max, d);
            }
            if (looksLikeDate(v)) {
                dateCount++;
            }
        }

        ColumnProfile toProfile(String name, long total) {
            String type = "TEXT";
            if (nonMissing > 0 && numericCount == nonMissing) {
                type = "NUMBER";
            } else if (nonMissing > 0 && dateCount >= Math.max(1, nonMissing * 0.8)) {
                type = "DATE";
            }
            Double avg = numericCount == 0 ? null : sum.divide(BigDecimal.valueOf(numericCount), java.math.MathContext.DECIMAL64).doubleValue();
            return new ColumnProfile(name, type, total, missing, distinct.size(), min, max, avg, List.copyOf(examples));
        }

        private Double parseDouble(String v) {
            try {
                String normalized = v.replace(",", "");
                return Double.parseDouble(normalized);
            } catch (NumberFormatException e) {
                return null;
            }
        }

        private boolean looksLikeDate(String v) {
            List<DateTimeFormatter> fs = List.of(
                    DateTimeFormatter.ISO_LOCAL_DATE,
                    DateTimeFormatter.ofPattern("yyyy/M/d", Locale.ROOT),
                    DateTimeFormatter.ofPattern("yyyy-M-d", Locale.ROOT)
            );
            for (DateTimeFormatter f : fs) {
                try {
                    LocalDate.parse(v, f);
                    return true;
                } catch (DateTimeParseException ignored) {}
            }
            return false;
        }
    }
}
