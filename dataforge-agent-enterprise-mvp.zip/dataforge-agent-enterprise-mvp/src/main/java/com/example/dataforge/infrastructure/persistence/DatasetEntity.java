package com.example.dataforge.infrastructure.persistence;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "datasets")
public class DatasetEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 255)
    private String originalFilename;

    @Column(nullable = false, length = 1024)
    private String storedPath;

    @Column(nullable = false)
    private long rowCount;

    @Column(nullable = false)
    private int columnCount;

    @Column(nullable = false, columnDefinition = "CLOB")
    private String columnsJson;

    @Column(nullable = false, columnDefinition = "CLOB")
    private String sampleRowsJson;

    @Column(nullable = false)
    private Instant createdAt;

    protected DatasetEntity() {}

    public DatasetEntity(String originalFilename, String storedPath, long rowCount, int columnCount,
                         String columnsJson, String sampleRowsJson, Instant createdAt) {
        this.originalFilename = originalFilename;
        this.storedPath = storedPath;
        this.rowCount = rowCount;
        this.columnCount = columnCount;
        this.columnsJson = columnsJson;
        this.sampleRowsJson = sampleRowsJson;
        this.createdAt = createdAt;
    }

    public Long getId() { return id; }
    public String getOriginalFilename() { return originalFilename; }
    public String getStoredPath() { return storedPath; }
    public long getRowCount() { return rowCount; }
    public int getColumnCount() { return columnCount; }
    public String getColumnsJson() { return columnsJson; }
    public String getSampleRowsJson() { return sampleRowsJson; }
    public Instant getCreatedAt() { return createdAt; }
}
