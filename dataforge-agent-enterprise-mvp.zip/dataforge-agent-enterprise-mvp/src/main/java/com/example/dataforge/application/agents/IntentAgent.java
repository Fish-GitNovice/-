package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.agent.AgentIntent;
import org.springframework.stereotype.Component;

@Component
public class IntentAgent extends AbstractAgent {
    @Override
    protected String name() { return "IntentAgent"; }

    @Override
    protected String input(AgentContext context) { return context.getQuestion(); }

    @Override
    protected String doRun(AgentContext context) {
        String q = context.getQuestion().toLowerCase();
        AgentIntent intent;
        if (contains(q, "异常", "离群", "风险", "问题", "波动")) {
            intent = AgentIntent.ANOMALY_DETECTION;
        } else if (contains(q, "趋势", "按月", "按日", "变化")) {
            intent = AgentIntent.TREND_ANALYSIS;
        } else if (contains(q, "前", "top", "排名", "最高", "最低")) {
            intent = AgentIntent.RANKING;
        } else if (contains(q, "报告", "总结", "生成文档", "markdown")) {
            intent = AgentIntent.REPORT_GENERATION;
        } else if (contains(q, "sql")) {
            intent = AgentIntent.SQL_GENERATION;
        } else {
            intent = AgentIntent.KPI_QUERY;
        }
        context.setIntent(intent);
        return "意图识别结果=" + intent;
    }

    private boolean contains(String q, String... words) {
        for (String w : words) {
            if (q.contains(w.toLowerCase())) return true;
        }
        return false;
    }
}
