package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.agent.AgentIntent;
import com.example.dataforge.domain.dataset.ColumnProfile;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

@Component
public class SqlPlannerAgent extends AbstractAgent {
    private static final Map<String, List<String>> ALIASES = Map.of(
            "region", List.of("地区", "区域", "省份", "城市"),
            "category", List.of("品类", "类别", "分类", "商品"),
            "channel", List.of("渠道", "来源", "平台"),
            "amount", List.of("销售额", "金额", "收入", "交易额", "gmv"),
            "sales", List.of("销售额", "金额", "收入", "交易额", "gmv"),
            "revenue", List.of("销售额", "金额", "收入", "交易额", "gmv"),
            "profit", List.of("利润", "毛利", "收益"),
            "order_date", List.of("日期", "时间", "下单时间", "订单日期")
    );

    @Override
    protected String name() { return "SqlPlannerAgent"; }

    @Override
    protected String input(AgentContext context) {
        return "intent=" + context.getIntent() + ", question=" + context.getQuestion();
    }

    @Override
    protected String doRun(AgentContext context) {
        String q = context.getQuestion().toLowerCase(Locale.ROOT);
        List<ColumnProfile> columns = context.getDatasetProfile().columns();
        ColumnProfile metric = chooseMetric(q, columns);
        ColumnProfile dimension = chooseDimension(q, columns);
        ColumnProfile date = chooseDate(q, columns);

        String sql;
        if (contains(q, "多少条", "总数", "记录数", "count")) {
            sql = "SELECT COUNT(*) AS total_count FROM dataset";
        } else if (context.getIntent() == AgentIntent.ANOMALY_DETECTION && metric != null) {
            sql = "SELECT * FROM dataset WHERE " + qi(metric.name()) + " > " +
                    "(SELECT AVG(" + qi(metric.name()) + ") + 3 * STDDEV_SAMP(" + qi(metric.name()) + ") FROM dataset) " +
                    "ORDER BY " + qi(metric.name()) + " DESC LIMIT 20";
        } else if (context.getIntent() == AgentIntent.TREND_ANALYSIS && date != null && metric != null) {
            sql = "SELECT date_trunc('month', CAST(" + qi(date.name()) + " AS DATE)) AS month, " +
                    "SUM(" + qi(metric.name()) + ") AS total_" + safeAlias(metric.name()) +
                    " FROM dataset GROUP BY month ORDER BY month";
        } else if ((context.getIntent() == AgentIntent.RANKING || contains(q, "按", "统计", "分组")) && dimension != null && metric != null) {
            int limit = q.contains("前10") || q.contains("top10") ? 10 : 5;
            sql = "SELECT " + qi(dimension.name()) + " AS dimension, SUM(" + qi(metric.name()) + ") AS total_" + safeAlias(metric.name()) +
                    " FROM dataset GROUP BY " + qi(dimension.name()) + " ORDER BY total_" + safeAlias(metric.name()) + " DESC LIMIT " + limit;
        } else if (contains(q, "平均", "avg") && metric != null) {
            sql = "SELECT AVG(" + qi(metric.name()) + ") AS avg_" + safeAlias(metric.name()) + " FROM dataset";
        } else if (contains(q, "最大", "最高", "max") && metric != null) {
            sql = "SELECT MAX(" + qi(metric.name()) + ") AS max_" + safeAlias(metric.name()) + " FROM dataset";
        } else if (contains(q, "最小", "最低", "min") && metric != null) {
            sql = "SELECT MIN(" + qi(metric.name()) + ") AS min_" + safeAlias(metric.name()) + " FROM dataset";
        } else if (metric != null) {
            sql = "SELECT SUM(" + qi(metric.name()) + ") AS total_" + safeAlias(metric.name()) +
                    ", AVG(" + qi(metric.name()) + ") AS avg_" + safeAlias(metric.name()) + " FROM dataset";
        } else {
            sql = "SELECT * FROM dataset LIMIT 20";
        }

        context.setPlannedSql(sql);
        return sql;
    }

    private ColumnProfile chooseMetric(String q, List<ColumnProfile> columns) {
        Optional<ColumnProfile> matched = columns.stream()
                .filter(c -> "NUMBER".equals(c.type()))
                .max(Comparator.comparingInt(c -> score(q, c.name())));
        if (matched.isPresent() && score(q, matched.get().name()) > 0) return matched.get();
        return columns.stream().filter(c -> "NUMBER".equals(c.type()))
                .filter(c -> !c.name().toLowerCase(Locale.ROOT).contains("id"))
                .findFirst().orElse(null);
    }

    private ColumnProfile chooseDimension(String q, List<ColumnProfile> columns) {
        Optional<ColumnProfile> matched = columns.stream()
                .filter(c -> !"NUMBER".equals(c.type()))
                .filter(c -> c.distinctCount() <= 200)
                .max(Comparator.comparingInt(c -> score(q, c.name())));
        if (matched.isPresent() && score(q, matched.get().name()) > 0) return matched.get();
        return columns.stream().filter(c -> !"NUMBER".equals(c.type()))
                .filter(c -> c.distinctCount() > 1 && c.distinctCount() <= 50)
                .findFirst().orElse(null);
    }

    private ColumnProfile chooseDate(String q, List<ColumnProfile> columns) {
        return columns.stream()
                .filter(c -> "DATE".equals(c.type())
                        || c.name().toLowerCase(Locale.ROOT).contains("date")
                        || c.name().toLowerCase(Locale.ROOT).contains("time")
                        || (c.name().toLowerCase(Locale.ROOT).contains("order") && contains(q, "日期", "时间", "趋势", "按月", "按日")))
                .findFirst().orElse(null);
    }

    private int score(String q, String column) {
        String c = column.toLowerCase(Locale.ROOT);
        int s = 0;
        if (q.contains(c)) s += 5;
        if (c.contains("amount") || c.contains("sales") || c.contains("revenue")) {
            if (contains(q, "销售额", "金额", "收入", "gmv")) s += 6;
        }
        if (c.contains("profit") && contains(q, "利润", "毛利", "收益")) s += 6;
        if (c.contains("region") && contains(q, "地区", "区域", "省份", "城市")) s += 6;
        if (c.contains("category") && contains(q, "品类", "类别", "分类", "商品")) s += 6;
        if (c.contains("channel") && contains(q, "渠道", "来源", "平台")) s += 6;
        if (c.contains("date") && contains(q, "日期", "时间", "趋势", "按月", "按日")) s += 6;
        for (var entry : ALIASES.entrySet()) {
            if (c.contains(entry.getKey())) {
                for (String alias : entry.getValue()) {
                    if (q.contains(alias)) s += 3;
                }
            }
        }
        return s;
    }

    private boolean contains(String q, String... words) {
        for (String w : words) if (q.contains(w.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private String qi(String identifier) {
        return "\"" + identifier.replace("\"", "\"\"") + "\"";
    }

    private String safeAlias(String name) {
        return name.replaceAll("[^a-zA-Z0-9_]", "_");
    }
}
