package com.example.dataforge.domain.agent;

public record AgentStep(
        String agentName,
        String input,
        String output,
        String status,
        long latencyMs,
        int estimatedTokens
) {}
