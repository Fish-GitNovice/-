package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.agent.AgentIntent;
import com.example.dataforge.domain.agent.QueryResult;
import com.example.dataforge.domain.dataset.ColumnProfile;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class InsightAgent extends AbstractAgent {
    @Override
    protected String name() { return "InsightAgent"; }

    @Override
    protected String input(AgentContext context) {
        return "intent=" + context.getIntent() + ", rows=" + (context.getQueryResult() == null ? 0 : context.getQueryResult().rowCount());
    }

    @Override
    protected String doRun(AgentContext context) {
        List<String> insights = new ArrayList<>();
        QueryResult result = context.getQueryResult();
        if (result == null || result.rows().isEmpty()) {
            insights.add("没有查询到结果，可尝试更换问题或检查数据质量。 ");
        } else {
            Map<String, Object> first = result.rows().get(0);
            if (first.containsKey("total_count")) {
                insights.add("数据集共有 " + first.get("total_count") + " 条记录。 ");
            } else if (context.getIntent() == AgentIntent.ANOMALY_DETECTION) {
                insights.add("异常检测返回 " + result.rowCount() + " 条疑似高值异常记录，建议结合业务阈值二次确认。 ");
            } else if (first.containsKey("dimension")) {
                insights.add("排名第一的维度值是「" + first.get("dimension") + "」，对应指标为 " + metricValue(first) + "。 ");
                if (result.rowCount() >= 3) {
                    insights.add("Top 维度之间可能存在明显差异，可优先关注排名前 3 的区域/渠道/品类。 ");
                }
            } else {
                insights.add("查询已完成，当前结果可作为进一步报告生成和业务复盘的依据。 ");
            }
        }

        long missingColumns = context.getDatasetProfile().columns().stream().filter(c -> c.missingCount() > 0).count();
        if (missingColumns > 0) {
            insights.add("数据质量提醒：存在 " + missingColumns + " 个字段有缺失值，指标分析前建议确认缺失值处理策略。 ");
        }
        context.getDatasetProfile().columns().stream()
                .filter(c -> "NUMBER".equals(c.type()) && c.max() != null && c.avg() != null && c.max() > c.avg() * 5)
                .findFirst()
                .ifPresent(c -> insights.add("潜在异常提醒：字段「" + c.name() + "」最大值明显高于均值，可能存在大额订单或离群点。 "));

        context.getInsights().addAll(insights);
        return String.join("\n", insights);
    }

    private Object metricValue(Map<String, Object> row) {
        return row.entrySet().stream()
                .filter(e -> !"dimension".equals(e.getKey()))
                .map(Map.Entry::getValue)
                .findFirst().orElse("");
    }
}
