package com.example.dataforge.api.dto;

import com.example.dataforge.domain.dataset.ColumnProfile;

import java.time.Instant;
import java.util.List;
import java.util.Map;

public record DatasetProfileResponse(
        Long id,
        String name,
        long rowCount,
        List<ColumnProfile> columns,
        List<Map<String, Object>> sampleRows,
        Instant createdAt
) {}
