package com.example.dataforge.domain.agent;

import java.util.List;
import java.util.Map;

public record QueryResult(
        List<String> columns,
        List<Map<String, Object>> rows
) {
    public int rowCount() {
        return rows == null ? 0 : rows.size();
    }
}
