package com.example.dataforge.application.agents;

import com.example.dataforge.domain.agent.AgentContext;
import com.example.dataforge.domain.dataset.ColumnProfile;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
public class DatasetContextAgent extends AbstractAgent {
    @Override
    protected String name() {
        return "DatasetContextAgent";
    }

    @Override
    protected String input(AgentContext context) {
        return "datasetId=" + context.getDataset().getId() + ", question=" + context.getQuestion();
    }

    @Override
    protected String doRun(AgentContext context) {
        String cols = context.getDatasetProfile().columns().stream()
                .map(this::brief)
                .collect(Collectors.joining("; "));
        return "已读取数据画像：行数=" + context.getDatasetProfile().rowCount() + "，字段=" + cols;
    }

    private String brief(ColumnProfile c) {
        return c.name() + "(" + c.type() + ", missing=" + c.missingCount() + ", distinct=" + c.distinctCount() + ")";
    }
}
