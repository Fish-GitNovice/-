package com.example.dataforge.application;

import com.example.dataforge.api.dto.LoginRequest;
import com.example.dataforge.api.dto.LoginResponse;
import com.example.dataforge.common.BusinessException;
import com.example.dataforge.security.JwtService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final String devUsername;
    private final String devPassword;
    private final JwtService jwtService;
    private final long expiresSeconds;

    public AuthService(@Value("${app.security.dev-username}") String devUsername,
                       @Value("${app.security.dev-password}") String devPassword,
                       @Value("${app.security.jwt-expire-seconds}") long expiresSeconds,
                       JwtService jwtService) {
        this.devUsername = devUsername;
        this.devPassword = devPassword;
        this.expiresSeconds = expiresSeconds;
        this.jwtService = jwtService;
    }

    public LoginResponse login(LoginRequest request) {
        if (!devUsername.equals(request.username()) || !devPassword.equals(request.password())) {
            throw new BusinessException(401, "用户名或密码错误");
        }
        return new LoginResponse(jwtService.generateToken(request.username()), "Bearer", expiresSeconds);
    }
}
