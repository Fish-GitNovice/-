package com.example.dataforge.api.dto;

public record LoginResponse(String token, String tokenType, long expiresInSeconds) {}
