package com.example.dataforge.infrastructure.duckdb;

import com.example.dataforge.common.BusinessException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class SqlSafetyInspectorTest {
    private final SqlSafetyInspector inspector = new SqlSafetyInspector();

    @Test
    void shouldAllowSimpleSelectFromDataset() {
        assertDoesNotThrow(() -> inspector.assertSafeSelect("SELECT COUNT(*) FROM dataset"));
    }

    @Test
    void shouldRejectDelete() {
        assertThrows(BusinessException.class, () -> inspector.assertSafeSelect("DELETE FROM dataset"));
    }

    @Test
    void shouldRejectMultiStatement() {
        assertThrows(BusinessException.class, () -> inspector.assertSafeSelect("SELECT * FROM dataset; DROP TABLE users"));
    }

    @Test
    void shouldRejectOtherTable() {
        assertThrows(BusinessException.class, () -> inspector.assertSafeSelect("SELECT * FROM users"));
    }
}
