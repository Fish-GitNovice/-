# 申报表可填写内容

## 项目解决的核心痛点

我构建了一个 DataForge Multi-Agent 大数据洞察助手，解决普通用户面对 CSV、订单、日志等数据时不会写 SQL、难以快速获得指标洞察、异常判断和分析报告的问题。传统方式需要人工理解字段、编写 SQL、分析结果、整理报告，效率低且不易沉淀。该系统通过上传 CSV 后自动生成数据画像，并使用多 Agent 协作完成自然语言问题理解、SQL 规划、安全校验、DuckDB 查询、业务洞察和 Markdown 报告生成，让非专业用户也能快速完成数据分析。

## 核心逻辑流

系统包含 6 个 Agent：DatasetContextAgent 负责读取数据集画像，IntentAgent 负责识别用户意图，SqlPlannerAgent 将中文问题转换为安全 SELECT SQL，QueryExecuteAgent 使用 DuckDB 执行本地 OLAP 查询，InsightAgent 根据结果生成业务见解和异常提醒，ReportAgent 生成 Markdown 分析报告。系统还包含 JWT 鉴权、数据集元数据管理、SQL 安全护栏、Agent 执行轨迹审计等企业级模块。默认规则版 0 Token 可运行；若接入大模型，单次分析约 1200-2500 Token，并通过只传字段画像、限制结果行数、缓存 AgentRun 记录等方式控制成本。
