# DataForge Agent Enterprise MVP

一个符合“企业级项目体系”的多 Agent 大数据洞察助手 MVP。

它不是简单 Demo，而是按企业后端常见结构拆分：`api / application / domain / infrastructure / security / common`，并包含鉴权、元数据管理、审计、SQL 安全护栏、数据画像、DuckDB 查询、多 Agent 链路追踪和报告生成。

## 1. 项目解决的核心痛点

很多业务人员、运营同学、学生或初级开发拿到 CSV、订单表、日志表后，会遇到这些问题：

- 不会写 SQL，无法快速从数据中得到指标；
- 会写 SQL 但不知道该看哪些字段、哪些异常、哪些趋势；
- 临时分析结果没有沉淀，缺少报告、审计和执行轨迹；
- 直接让大模型读全量数据 Token 成本高、还可能泄露敏感数据；
- AI 生成 SQL 存在误操作风险，企业环境需要安全护栏。

DataForge 的设计目标是：用户上传 CSV 后，只需要用中文提问，系统自动完成数据理解、SQL 规划、安全校验、DuckDB 查询、业务洞察和 Markdown 报告生成。

## 2. 核心逻辑流：多 Agent 协作链路

一次提问会经过以下链路：

```text
用户上传 CSV
  -> DatasetService 保存文件
  -> CsvProfiler 自动生成字段画像、缺失值、distinct、数值分布、样例行
  -> 用户输入问题
  -> AgentOrchestrator 编排多个 Agent
      1. DatasetContextAgent：读取数据集画像，构造数据上下文
      2. IntentAgent：判断用户意图，例如指标查询、排名、趋势、异常检测、报告生成
      3. SqlPlannerAgent：把中文问题转换成只读 SELECT SQL
      4. QueryExecuteAgent：SQL 安全校验后，用 DuckDB 对 CSV 做本地 OLAP 查询
      5. InsightAgent：根据查询结果和数据画像生成业务洞察、异常提醒、数据质量提醒
      6. ReportAgent：生成 Markdown 分析报告
  -> AgentRunEntity 落库保存执行记录、SQL、结果、Trace
  -> 返回前端展示
```

## 3. 技术栈

- Java 17
- Spring Boot 3
- Spring MVC
- Spring Security + JWT
- Spring Data JPA
- H2 本地元数据库
- DuckDB JDBC 本地 OLAP 查询
- Apache Commons CSV 数据解析
- SpringDoc OpenAPI / Swagger
- 原生 HTML 前端
- JUnit 5 单元测试
- Dockerfile + docker-compose

## 4. 快速运行

确保本机安装 JDK 17+ 和 Maven 3.8+。

```bash
cd dataforge-agent-enterprise-mvp
mvn spring-boot:run
```

启动后访问：

```text
http://localhost:8080
```

默认账号：

```text
admin / admin123
```

上传示例数据：

```text
sample_data/orders.csv
```

Swagger：

```text
http://localhost:8080/swagger-ui.html
```

H2 控制台：

```text
http://localhost:8080/h2-console
JDBC URL: jdbc:h2:file:./data/dataforge-meta
User: sa
Password: 空
```

## 5. 可测试问题

```text
按地区统计销售额前5名，并给出业务洞察
平均利润是多少
哪些记录可能存在销售额异常
按渠道统计销售额
这个数据集有多少条记录
按月份查看销售额趋势
```

## 6. 接口说明

### 登录

```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "admin",
  "password": "admin123"
}
```

### 上传 CSV

```http
POST /api/datasets
Authorization: Bearer <token>
Content-Type: multipart/form-data

file=@orders.csv
```

### 查看数据集画像

```http
GET /api/datasets/{id}/profile
Authorization: Bearer <token>
```

### Agent 问答

```http
POST /api/agent/chat
Authorization: Bearer <token>
Content-Type: application/json

{
  "datasetId": 1,
  "question": "按地区统计销售额前5名，并给出业务洞察"
}
```

返回内容包含：

- runId：本次 Agent 运行记录 ID
- answer：自然语言答案
- sql：自动生成的 SQL
- rows：DuckDB 查询结果
- insights：洞察列表
- reportMarkdown：Markdown 报告
- steps：每个 Agent 的输入、输出、耗时、估算 Token

## 7. 企业级体系体现在哪里

### 7.1 分层架构

```text
api              Controller 和 DTO
application      业务用例、Agent 编排、服务层
domain           数据集画像、Agent 上下文、查询结果等领域对象
infrastructure   CSV、DuckDB、JPA、文件存储等基础设施
security         JWT 鉴权和 Spring Security 配置
common           统一响应、异常处理
```

### 7.2 安全设计

- JWT 无状态鉴权；
- 接口默认需要登录；
- SQL 只允许 SELECT；
- 禁止 DROP、DELETE、UPDATE、CREATE、COPY、ATTACH、LOAD、PRAGMA 等危险关键字；
- 禁止多语句和注释注入；
- SQL 只能查询虚拟表 dataset，不能访问任意本地文件；
- 上传文件限制为 CSV；
- 全局异常统一返回。

### 7.3 数据治理

- 上传数据集后自动保存元数据；
- 自动生成字段类型、缺失值、distinct、min、max、avg、样例行；
- 查询结果和 Agent 轨迹落库，方便复盘和审计；
- 数据文件和元数据分离。

### 7.4 可扩展性

当前 MVP 使用规则版 SQL Planner，保证 0 Token 可运行。后续可以替换为：

- OpenAI / DeepSeek / Qwen 等大模型 SQL Planner；
- Kafka / Flink / Spark 数据源；
- PostgreSQL / MySQL / Hive / ClickHouse 真实数仓；
- 多租户 RBAC；
- 异步任务队列；
- 报告导出 PDF / Word；
- 数据脱敏和权限列过滤；
- RAG 知识库解释业务指标口径。

## 8. Token Plan / 成本控制设计

默认规则版：

```text
LLM Token 消耗：0
```

如果接入大模型，推荐策略：

```text
1. 不把全量 CSV 发给模型，只发送字段画像、样例行、用户问题。
2. SQL 生成阶段控制在 600 - 1000 Token。
3. 洞察生成阶段只发送聚合结果前 20 - 50 行，控制在 800 - 1500 Token。
4. 报告生成阶段使用结构化模板，尽量减少长上下文。
5. AgentRunEntity 保存执行结果，重复问题可做缓存。
```

单次分析预估：

```text
规则版：0 Token
LLM 增强版：约 1200 - 2500 Token / 次
```

## 9. Docker 运行

```bash
docker compose up --build
```

然后访问：

```text
http://localhost:8080
```

## 10. 生产化还需要补充什么

这个项目已经是企业级体系 MVP，但还不是完整生产系统。真实上线还需要：

- 接入真实用户表、RBAC、组织/租户；
- 用 PostgreSQL / MySQL 替换 H2；
- 文件存储切换到 MinIO / S3；
- 增加异步任务、任务取消、重试和超时控制；
- 增加 Prometheus + Grafana 监控；
- 增加脱敏、列级权限、数据血缘；
- 增加更完善的集成测试和压力测试；
- 增加 CI/CD。

MVP 的价值是：它已经把“智能体 + 大数据分析 + 企业后端工程结构”完整串起来了，适合用于创新项目申报、简历项目、课程展示和后续二次开发。
